import React from 'react'

const Nosotros = () => {
  return (
    <div>Nosotros</div>
  )
}

export default Nosotros