import React from 'react'

export const Servicios = () => {
  return (
    <div>Servicios</div>
  )
}
