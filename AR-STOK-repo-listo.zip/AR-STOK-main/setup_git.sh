#!/usr/bin/env bash
# Usa: bash setup_git.sh TU-USUARIO AR-STOK
USER_NAME="$1"
REPO_NAME="$2"

if [ -z "$USER_NAME" ] || [ -z "$REPO_NAME" ]; then
  echo "Uso: bash setup_git.sh TU-USUARIO NOMBRE-REPO"
  exit 1
fi

set -e
git init
git add .
git commit -m "chore: primer commit"
git branch -M main
git remote add origin https://github.com/$USER_NAME/$REPO_NAME.git
git push -u origin main

echo "Listo. Repositorio subido a https://github.com/$USER_NAME/$REPO_NAME"
