# Cómo contribuir

Gracias por tu interés en mejorar este proyecto 🙌

## Reglas sencillas
- Crea una rama por cambio (feature o fix).
- Escribe commits claros (ej.: `feat: mapa de atractivos`).
- Antes de subir, prueba el proyecto: `npm run dev` y `npm run build`.
- Abre un Pull Request explicando **qué** cambiaste y **por qué**.
