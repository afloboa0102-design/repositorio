# AR-STOK · Guía Turística de Cali (Frontend con Vite)

Este proyecto es una **app web** (sitio web que funciona en el navegador) hecha con **Vite** (empacador rápido) y **React** (biblioteca para construir interfaces).

## 🚀 Requisitos (qué necesitas)
- **Node.js 18 o 20 LTS** (versión estable de Node).
- **Git** (control de versiones).

## ▶️ Cómo ejecutarlo en tu computador (entorno local)
```bash
# 1) Instala las dependencias (bibliotecas que el proyecto usa)
npm install

# 2) Arranca el servidor de desarrollo (modo programador)
npm run dev
```
- Luego abre la URL que te muestre la terminal (normalmente http://localhost:5173).

## 🧱 Scripts disponibles (atajos)
- `npm run dev` – arranca en modo desarrollo.
- `npm run build` – genera la versión lista para publicar (carpeta `dist`).
- `npm run preview` – revisa localmente la versión final.

## 🔧 Estructura principal
- `src/` – código fuente de la app.
- `public/` – archivos públicos (imágenes, íconos).
- `index.html` – punto de entrada del sitio.
- `vite.config.js` – configuración de Vite.

## ☁️ Publicación (subir a internet)
1. Ejecuta el build:
   ```bash
   npm run build
   ```
2. Sube la carpeta `dist/` a un hosting estático como **Netlify**, **Vercel** o **GitHub Pages** (servicios que alojan páginas web).

## 📦 Cómo crear y conectar el repositorio (Git + GitHub)
> *(Repositorio = “caja” donde vive el código y su historial)*

1. Inicia Git en la carpeta del proyecto:
   ```bash
   git init
   git add .
   git commit -m "chore: primer commit"
   ```

2. Crea un repositorio en GitHub y copia su URL (ej.: `https://github.com/TU-USUARIO/AR-STOK.git`).

3. Conecta y sube:
   ```bash
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/AR-STOK.git
   git push -u origin main
   ```

## 🧹 Buenas prácticas
- Usa **commits descriptivos** (mensajes claros de lo que cambiaste).
- Crea ramas por feature (nueva función) o fix (arreglo).
- Revisa el código con `ESLint` antes de subir cambios.

## 📝 Licencia
MIT – úsalo libremente recordando dar créditos.
